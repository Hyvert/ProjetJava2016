package gfx;

import java.awt.Button;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

import api.*;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.AbstractAction;
import javax.swing.Action;

/**
 * Cr�e l'interface pour la bataille.
 * @author Vicblivion et Yvan Ugresic
 */
@SuppressWarnings("unchecked")
public class Warfare extends JFrame {

	private static Font font = new Font("Georgia", Font.BOLD, 24);
	private JPanel content;
	private JLabel grilT;
	private JLabel grilN;
	private JTable grilleT;
	private JTable grilleN;
	
	private JLabel tour;
	private JLabel coord;
	private JLabel FinDePartie;
	private JComboBox lettre;
	private JComboBox chiffre;
	private Button val;
	private static String[] cbl={"A","B","C","D","E","F","G","H","I","J"};
	private static String[] cbc={"1","2","3","4","5","6","7","8","9","10"};
	
	private Joueur un;
	private Joueur deux;
	private static int compte;
	private static int ctemp=0;
	private char type;
	private Compteur c=new Compteur();
	private static JLabel lbllettre;
	private JComboBox comboBox_Sens;
	private JPanel panelPlacer;
	private JPanel panelJeu;
	private JButton btnDemarrer;
	private JComboBox comboBoxNavire;
	private JComboBox comboBox_placerY;
	private JComboBox comboBox_placerX; 
	private JLabel lblErreur;
	private JLabel lblRadar;
	private int joueursPret=0;
	private TypeNavire zod;
	private TypeNavire cui;
	private TypeNavire sma;
	private TypeNavire pav;
	public Warfare(Joueur A, Joueur B, char t){
		un=A;
		deux=B;
		type=t;
		
		//compte=un.getUnite(0).nbCompartiment()+un.getUnite(1).nbCompartiment()+un.getUnite(2).nbCompartiment()+un.getUnite(3).nbCompartiment()+un.getUnite(4).nbCompartiment();
		
		this.setSize(800,480);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
		content = new JPanel();
		content.setLayout(null);
		this.setContentPane(content);
		
		grilT = new JLabel("Grille de tir");
		grilT.setFont(font);
		grilT.setBounds(10,5,300,30);
		content.add(grilT);
		
		grilN=new JLabel("Grille des navires");
		grilN.setFont(font);
		grilN.setBounds(10,220,350,30);
		content.add(grilN);
		
		FinDePartie = new JLabel("Fin de partie");
		FinDePartie.setHorizontalAlignment(SwingConstants.CENTER);
		FinDePartie.setFont(new Font("Georgia", Font.BOLD, 24));
		FinDePartie.setBounds(350, 150, 157, 30);
		content.add(FinDePartie);
		
		content.repaint();
		
		Object tir[][]={
				{null,"A","B","C","D","E","F","G","H","I","J"},
				{1,null,null,null,null,null,null,null,null,null,null},
				{2,null,null,null,null,null,null,null,null,null,null},
				{3,null,null,null,null,null,null,null,null,null,null},
				{4,null,null,null,null,null,null,null,null,null,null},
				{5,null,null,null,null,null,null,null,null,null,null},
				{6,null,null,null,null,null,null,null,null,null,null},
				{7,null,null,null,null,null,null,null,null,null,null},
				{8,null,null,null,null,null,null,null,null,null,null},
				{9,null,null,null,null,null,null,null,null,null,null},
				{10,null,null,null,null,null,null,null,null,null,null}
		};
		String titre[]={"Chiffre","A","B","C","D","E","F","G","H","I","J"};
		grilleT=new JTable(tir,titre);
		grilleT.setBounds(10,40,330,175);
		content.add(grilleT);
		
		Object nav[][]={
				{null,"A","B","C","D","E","F","G","H","I","J"},
				{1,null,null,null,null,null,null,null,null,null,null},
				{2,null,null,null,null,null,null,null,null,null,null},
				{3,null,null,null,null,null,null,null,null,null,null},
				{4,null,null,null,null,null,null,null,null,null,null},
				{5,null,null,null,null,null,null,null,null,null,null},
				{6,null,null,null,null,null,null,null,null,null,null},
				{7,null,null,null,null,null,null,null,null,null,null},
				{8,null,null,null,null,null,null,null,null,null,null},
				{9,null,null,null,null,null,null,null,null,null,null},
				{10,null,null,null,null,null,null,null,null,null,null}
		};
		grilleN=new JTable(nav,titre);
		grilleN.setBounds(10,255,330,175);
		content.add(grilleN);
		
		panelJeu = new JPanel();
		panelJeu.setBounds(350, 40, 350, 210);
		content.add(panelJeu);
		panelJeu.setLayout(null);
		
		tour=new JLabel("Tour du Joueur");
		tour.setBounds(10, 11, 194, 28);
		panelJeu.add(tour);
		tour.setFont(font);
		
		coord=new JLabel("Coordonn�e de la frappe");
		coord.setBounds(10, 42, 350, 30);
		panelJeu.add(coord);
		coord.setFont(font);
		
		lettre=new JComboBox(cbl);
		lettre.setBounds(10, 83, 40, 20);
		panelJeu.add(lettre);
		lettre.setMaximumRowCount(10);
		
		lbllettre = new JLabel("A");
		lbllettre.setBounds(10, 86, 40, 14);
		panelJeu.add(lbllettre);
		
		
		chiffre=new JComboBox(cbc);
		chiffre.setBounds(60, 83, 40, 20);
		panelJeu.add(chiffre);
		chiffre.setMaximumRowCount(10);
		
		
		
		val=new Button("Valider");
		val.setBounds(104, 78, 100, 30);
		panelJeu.add(val);
		
		lblRadar = new JLabel("");
		lblRadar.setBounds(10, 147, 77, 14);
		panelJeu.add(lblRadar);
		
		panelPlacer = new JPanel();
		panelPlacer.setBounds(350, 261, 317, 169);
		content.add(panelPlacer);
		panelPlacer.setLayout(null);
		
		btnDemarrer = new JButton("D\u00E9marrer");
		btnDemarrer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!un.getUnites().isEmpty()){
					if (joueursPret<2){
						joueursPret++;
						Joueur temp = new Joueur(deux);
						deux = new Joueur(un);
						un = new Joueur(temp);
						init();
					}
					else{
						try {
							panelJeu.setVisible(true);
							panelPlacer.setVisible(false);
							Mode.lance(type,un,deux);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
					}
				}
				else lblErreur.setText("Il faut placer des navires !");
			}
		});
		btnDemarrer.setBounds(218, 140, 89, 23);
		panelPlacer.add(btnDemarrer);
		
		comboBoxNavire = new JComboBox();
		comboBoxNavire.setModel(new DefaultComboBoxModel(new String[] {"Zodiac", "Cuirass\u00E9 furtif", "Sous-marin", "Porte-avion"}));
		comboBoxNavire.setBounds(11, 50, 130, 20);
		panelPlacer.add(comboBoxNavire);
		
		comboBox_placerY = new JComboBox();
		comboBox_placerY.setModel(new DefaultComboBoxModel(new String[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"}));
		comboBox_placerY.setBounds(11, 81, 45, 20);
		panelPlacer.add(comboBox_placerY);
		
		comboBox_placerX = new JComboBox();
		comboBox_placerX.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		comboBox_placerX.setBounds(66, 81, 45, 20);
		panelPlacer.add(comboBox_placerX);
		
		lblErreur = new JLabel("");
		lblErreur.setForeground(Color.RED);
		lblErreur.setBounds(10, 149, 198, 14);
		panelPlacer.add(lblErreur);
		
		JLabel lblPlacezVosNavires = new JLabel("Placez vos navires");
		lblPlacezVosNavires.setFont(new Font("Georgia", Font.BOLD, 24));
		lblPlacezVosNavires.setBounds(10, 11, 236, 28);
		panelPlacer.add(lblPlacezVosNavires);
		
		comboBox_Sens = new JComboBox();
		comboBox_Sens.setModel(new DefaultComboBoxModel(new String[] {"haut", "bas", "gauche", "droite"}));
		comboBox_Sens.setBounds(121, 81, 61, 20);
		panelPlacer.add(comboBox_Sens);
		
		JButton btnPlacer = new JButton("Placer");
		btnPlacer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TypeNavire typeSel= getTypeSelect();
				if (typeSel.getQuantite() < 1) {
					lblErreur.setText("Navire indisponible.");
				}
				else{
					boolean reussi;
					if(comboBox_Sens.getSelectedItem()=="haut"){
						Navire newnav=new Navire(comboBox_placerX.getSelectedIndex(),comboBox_placerY.getSelectedIndex(),'h',typeSel);
						reussi=placerNavire(newnav,un);
					}
					else if(comboBox_Sens.getSelectedItem()=="bas"){
						Navire newnav=new Navire(comboBox_placerX.getSelectedIndex(),comboBox_placerY.getSelectedIndex(),'b',typeSel);
						reussi=placerNavire(newnav,un);
					}
					else if(comboBox_Sens.getSelectedItem()=="gauche"){
						Navire newnav=new Navire(comboBox_placerX.getSelectedIndex(),comboBox_placerY.getSelectedIndex(),'g',typeSel);
						reussi=placerNavire(newnav,un);
					}
					else {
						Navire newnav=new Navire(comboBox_placerX.getSelectedIndex(),comboBox_placerY.getSelectedIndex(),'d',typeSel);
						reussi=placerNavire(newnav,un);
					}
					if (!reussi){
						lblErreur.setText("Position indisponible.");
					}
					else {
						lblErreur.setText("");
						utiliserTypeNav();
						rafraichirListeNavire(un);
					}
					Menu.war.refresh(un);
				}
				
			}

			private void utiliserTypeNav() {
				TypeNavire typeSel= getTypeSelect();
				if (typeSel.getTaille()==zod.getTaille())
					zod.setQuantite(zod.getQuantite()-1);
				else if (typeSel.getTaille()==cui.getTaille())
					cui.setQuantite(cui.getQuantite()-1);
				else if (typeSel.getTaille()==sma.getTaille())
					sma.setQuantite(sma.getQuantite()-1);
				else
					pav.setQuantite(pav.getQuantite()-1);
			}
		});
		btnPlacer.setBounds(5, 115, 89, 23);
		panelPlacer.add(btnPlacer);
		val.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				switch(type){
					case 'n' :
						if(!grilleT.getValueAt(Integer.parseInt(""+chiffre.getSelectedItem()),transfo(""+lettre.getSelectedItem())).equals("X")){
							if(tirH(Integer.parseInt(""+chiffre.getSelectedItem()),transfo((String)(lettre.getSelectedItem())),un,deux)){
								if(Menu.war.un.getTour()==true){api.Type.missionNormale(deux,un);}
								else{
									Menu.war.un.setTour(true);
									api.Type.missionNormale(un,deux);
								}
							}
						}
						break;
					case 'r' :
						if(!grilleT.getValueAt(Integer.parseInt(""+chiffre.getSelectedItem()),transfo(""+lettre.getSelectedItem())).equals("X")){
							if (tirH(Integer.parseInt(""+chiffre.getSelectedItem()),transfo((String)(lettre.getSelectedItem())),un,deux)){
								if(Menu.war.un.getTour()==true){api.Type.missionRadar(deux,un);}
								else{
									Menu.war.un.setTour(true);
									api.Type.missionRadar(un,deux);
								}
							}
						}
						break;
					case 'a' :
						if(!grilleT.getValueAt(Integer.parseInt(""+chiffre.getSelectedItem()),transfo(""+lbllettre.getText())).equals("X")){
							if (tirH(Integer.parseInt(""+chiffre.getSelectedItem()),c.getI(),un,deux)){
								if(Menu.war.un.getTour()==true){api.Type.missionArtillerie(deux,un);}
								else{
									Menu.war.un.setTour(true);
									api.Type.missionArtillerie(un,deux);
								}
							}
						}
						break;
					case 'o' :
						if(!grilleT.getValueAt(Integer.parseInt(""+chiffre.getSelectedItem()),transfo(""+lbllettre.getText())).equals("X")){
							if (tirH(Integer.parseInt(""+chiffre.getSelectedItem()),c.getI(),un,deux)){
								if(Menu.war.un.getTour()==true){api.Type.missionAlerte(deux,un);}
								else{
									Menu.war.un.setTour(true);
									api.Type.missionAlerte(un,deux);
								}
							}
						}
						break;
				}
			}
		});
		
		for(int i=0;i<10;i++){
			for(int j=0;j<10;j++){
				if(un.getNCase(i,j).getOccupe()==true){
					grilleN.setValueAt("N", i, j);
				}
			}
		}
		content.repaint();
	}
	
	
	public static void tir(int x, int y){
		if(Menu.war.grilleT.getValueAt(x,y)!=null){
			//Menu.war.grilleT.setValueAt("X"+Menu.war.grilleN.getValueAt(x,y), x, y);
			Menu.war.un.setTour(true);
		}
		else{
			Menu.war.grilleT.setValueAt("X", x, y);
		}
	}
	
	public boolean tirH(int x, int y, Joueur A,  Joueur B){
		if(Menu.war.un.getTour()){
			x--;y--;
			if(A.getTCase(x,y).getTouche()) return false;
			A.getTCase(x,y).setTouche(true);
			if(B.getNCase(x,y).getOccupe()){A.getTCase(x,y).setOccupe(true);}
			B.getNCase(x,y).setTouche(true);
			Menu.war.refresh(B);
		}
		else{
			x--;y--;
			if(B.getTCase(x,y).getTouche()) return false;
			B.getTCase(x,y).setTouche(true);
			if(A.getNCase(x,y).getOccupe()){B.getTCase(x,y).setOccupe(true);}
			A.getNCase(x,y).setTouche(true);
			Menu.war.refresh(A);
		}
		if(this.type=='r'||this.type=='o'){lblRadar.setText(Double.toString(un.radar(x, y, B)));}
		return true;
	}
	
	public JPanel getContent(){return content;}
	
	public int transfo(String s){
		if(s=="A"){return 1;}
		if(s=="B"){return 2;}
		if(s=="C"){return 3;}
		if(s=="D"){return 4;}
		if(s=="E"){return 5;}
		if(s=="F"){return 6;}
		if(s=="G"){return 7;}
		if(s=="H"){return 8;}
		if(s=="I"){return 9;}
		if(s=="J"){return 10;}
		return 0;
	}
	
	public Button getVal(){
		return val;
	}
	
	public JTable getGrilleT(){
		return grilleT;
	}
	
	public void refresh(Joueur un){
		compte=0;
		ctemp=0;
		for(int i=1;i<11;i++){
			for(int j=1;j<11;j++){
				//Grille de tir
				grilleT.setValueAt(null,i,j);
				if(un.getTCase(i-1,j-1).getOccupe()) compte++;
				if(un.getTCase(i-1,j-1).getTouche()){
					if(un.getTCase(i-1,j-1).getOccupe()){
						grilleT.setValueAt("XN", i, j);
						ctemp++;
					}
					else{
						grilleT.setValueAt("X", i, j);
					}
				}
				/*else if(un.getTCase(i-1,j-1).getOccupe()==true){
						grilleT.setValueAt("N",i,j);
				}*/
				
				//Grille des navires
				grilleN.setValueAt(null,i,j);
				if(un.getNCase(i-1,j-1).getTouche()==true){
					if(un.getNCase(i-1,j-1).getOccupe()==true){
						grilleN.setValueAt("XN", i, j);
					}else{
						grilleN.setValueAt("X", i, j);
					}
				}
				else if(un.getNCase(i-1,j-1).getOccupe()==true){
					grilleN.setValueAt("N", i, j);
				}
			}
		}
		
		if(ctemp==compte &&joueursPret==2){
			System.out.println("Victoire !");
			FinDePartie.setVisible(true);
			val.setVisible(false);
		}
		content.repaint();
	}
	
	public JComboBox getLettre() {
		return lettre;
	}


	public void init() {
		panelJeu.setVisible(false);
		FinDePartie.setVisible(false);
		comboBoxNavire.removeAllItems();
		zod=new TypeNavire(2);
		cui=new TypeNavire(3);
		sma=new TypeNavire(4);
		pav=new TypeNavire(5);
		comboBoxNavire.addItem(zod.getQuantite() + " : "+ zod.getNom());
		comboBoxNavire.addItem(cui.getQuantite() + " : "+ cui.getNom());
		comboBoxNavire.addItem(sma.getQuantite() + " : "+ sma.getNom());
		comboBoxNavire.addItem(pav.getQuantite() + " : "+ pav.getNom());
		
		
		if(type=='a' ||type=='o'){
			lettre.setVisible(false);
			if(! c.isAlive())
				c.start();
		}
		else{
			lbllettre.setVisible(false);
		}
		if(type=='n'||type=='a'){
			lblRadar.setVisible(false);
		}
		if(!un.getHumain()){
			int x=(int) (Math.random()*9);
			int y=(int) (Math.random()*9);
			Random z=new Random();
			String dir="hbdg";
			char c = dir.charAt(z.nextInt(dir.length()));
			while(zod.getQuantite()>0){
				Navire newnav=new Navire(x,y,c,zod.getTaille());
				if(placerNavire(newnav,un))	zod.setQuantite(zod.getQuantite()-1);
				x=(int) (Math.random()*10);
				y=(int) (Math.random()*10);
				c = dir.charAt(z.nextInt(dir.length()));
			}
			while(cui.getQuantite()>0){
				Navire newnav=new Navire(x,y,c,cui.getTaille());
				if(placerNavire(newnav,un))	cui.setQuantite(cui.getQuantite()-1);
				x=(int) (Math.random()*10);
				y=(int) (Math.random()*10);
				c = dir.charAt(z.nextInt(dir.length()));
			}
			while(sma.getQuantite()>0){
				Navire newnav=new Navire(x,y,c,sma.getTaille());
				if(placerNavire(newnav,un))	sma.setQuantite(sma.getQuantite()-1);
				x=(int) (Math.random()*10);
				y=(int) (Math.random()*10);
				c = dir.charAt(z.nextInt(dir.length()));
			}
			while(pav.getQuantite()>0){
				Navire newnav=new Navire(x,y,c,pav.getTaille());
				if(placerNavire(newnav,un))	pav.setQuantite(pav.getQuantite()-1);
				x=(int) (Math.random()*10);
				y=(int) (Math.random()*10);
				c = dir.charAt(z.nextInt(dir.length()));
			}
			
			joueursPret++;
			Joueur temp = new Joueur(deux);
			deux = new Joueur(un);
			un = new Joueur(temp);
			
		
			if (joueursPret==2){
				try {
					un.setTir(deux.getNavire());
					deux.setTir(un.getNavire());
					panelJeu.setVisible(true);
					panelPlacer.setVisible(false);
					Mode.lance(type,un,deux);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
			else init();
		}
		
	}
	
	public char traduireSens(int x){
		switch(x){
			case 0:return('h');
			case 1:return('b');
			case 2:return('g');
		}
		return('d');
	}
	
	public void rafraichirListeNavire(Joueur joueur){
		//ArrayList<Navire> navires=joueur.getUnites();
		comboBoxNavire.removeAllItems();
		comboBoxNavire.addItem(zod.getQuantite() + " : "+ zod.getNom());
		comboBoxNavire.addItem(cui.getQuantite() + " : "+ cui.getNom());
		comboBoxNavire.addItem(sma.getQuantite() + " : "+ sma.getNom());
		comboBoxNavire.addItem(pav.getQuantite() + " : "+ pav.getNom());
	}
	
	public TypeNavire getTypeSelect(){
		if (comboBoxNavire.getSelectedIndex()==0)	return zod;
		if (comboBoxNavire.getSelectedIndex()==1)	return cui;
		if (comboBoxNavire.getSelectedIndex()==2)	return sma;
		else	return pav;
	}
	
	/**
	 * V�rifie si le navire peut �tre plac� ou non.
	 * @param n Le navire � placer.
	 * @param j Le joueur qui place le navire
	 * @return true si l'emplacement est disponible, false sinon.
	 */
	public boolean check(Navire n, Joueur j){
		if(n.getSens()=='g'){
			if(n.getPosition().getY()-n.getTaille()>0){
				for(int i=0 ; i>-n.getTaille();i--){
					if(j.getNCase(n.getPosition().getX(), i+n.getPosition().getY()).getOccupe()){return false;}
				}
				return true;
			}
			else{return false;}
		}
		else{
			if(n.getSens()=='d'){
				if(n.getPosition().getY()+n.getTaille()<=10){
					for(int i=0 ; i<n.getTaille();i++){
						if(j.getNCase(n.getPosition().getX(),i+n.getPosition().getY()).getOccupe()){return false;}
						}
					return true;
				}
				else{return false;}
			}
			else{
				if(n.getSens()=='h'){
					if(n.getPosition().getX()-n.getTaille()>0){
						for(int i=0 ; i>-n.getTaille();i--){
							if(j.getNCase(i+n.getPosition().getX(),n.getPosition().getY()).getOccupe()){return false;}
							}
						return true;
					}
					else{return false;}
				}
				else{
					if(n.getSens()=='b'){
						if(n.getPosition().getX()+n.getTaille()<=10){
							for(int i=0 ; i<n.getTaille();i++){
								if(j.getNCase(i+n.getPosition().getX(),n.getPosition().getY()).getOccupe()){return false;}
								}
							return true;
						}
						else{return false;}
					}
				
				}
			}	
		}
		return false;
	}
	
	public boolean placerNavire( Navire n, Joueur j){
		if( check(n,j)){
			j.addUnite(n);
			return true;
		}
		return false;
	}

	public void placerNaviresIA(Joueur ia){
		int x=(int) (Math.random()*9);
		int y=(int) (Math.random()*9);
		Random z=new Random();
		String dir="hbdg";
		char c = dir.charAt(z.nextInt(dir.length()));
		while(pav.getQuantite()>0){
			Navire nav= new Navire(x, y, c, pav);
			while(!check(nav, ia)){
				x=(int) (Math.random()*9);
				y=(int) (Math.random()*9);
				c = dir.charAt(z.nextInt(dir.length()));
				nav= new Navire(x, y, c, pav);
			}
			ia.addUnite(nav);
		}
		while(cui.getQuantite()>0){
			Navire nav= new Navire(x, y, c, cui);
			while(!check(nav, ia)){
				x=(int) (Math.random()*9);
				y=(int) (Math.random()*9);
				c = dir.charAt(z.nextInt(dir.length()));
				nav= new Navire(x, y, c, cui);
			}
			ia.addUnite(nav);
		}
		while(sma.getQuantite()>0){
			Navire nav= new Navire(x, y, c, sma);
			while(!check(nav, ia)){
				x=(int) (Math.random()*9);
				y=(int) (Math.random()*9);
				c = dir.charAt(z.nextInt(dir.length()));
				nav= new Navire(x, y, c, sma);
			}
			ia.addUnite(nav);
		}
		while(zod.getQuantite()>0){
			Navire nav= new Navire(x, y, c, zod);
			while(!check(nav, ia)){
				x=(int) (Math.random()*9);
				y=(int) (Math.random()*9);
				c = dir.charAt(z.nextInt(dir.length()));
				nav= new Navire(x, y, c, zod);
			}
			ia.addUnite(nav);
		}
	}
	
	public static void coorArti(int coord){
		switch(coord){
			case 1:lbllettre.setText("A");
				break;
			case 2:lbllettre.setText("B");
				break;
			case 3:lbllettre.setText("C");
				break;
			case 4:lbllettre.setText("D");
				break;
			case 5:lbllettre.setText("E");
				break;
			case 6:lbllettre.setText("F");
				break;
			case 7:lbllettre.setText("G");
				break;
			case 8:lbllettre.setText("H");
				break;
			case 9:lbllettre.setText("I");
				break;
			case 10:lbllettre.setText("J");
				break;
		}
	}
}
