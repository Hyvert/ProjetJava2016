package gfx;

/**
 * Compteur permettant de r�aliser le mode artillerie.
 * @author Vicblivion et Yvan Ugresic
 * @version 2
 */
public class Compteur extends Thread{
	private int i;
	
	public int getI(){
		return i;
	}
	
	public void run(){
		i=1;
		while(true){
			try {
				Thread.sleep(1000);
				i++;
				if(i>10){i=1;}
				Warfare.coorArti(i);
			} 
			catch (InterruptedException e) {e.printStackTrace();}
		}
	}
}
