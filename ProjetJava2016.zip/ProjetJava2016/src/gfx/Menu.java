package gfx;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import api.Joueur;
import api.Mode;

/**
 * Ouvre un menu permettant de choisir les navirs � placer.
 * @author Vicblivion
 * @version 2
 */
public class Menu extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup groupeM = new ButtonGroup();
	private final ButtonGroup groupeT = new ButtonGroup();
	private JLabel titre;
	private JLabel mode;
	private JLabel type;
	private JRadioButton rbDemo;
	private JRadioButton rb1J;
	private JRadioButton rb2J;
	private JRadioButton normale;
	private JRadioButton radar;
	private JRadioButton artillerie;
	private JRadioButton rouge;
	//private Thread t;
	protected static Warfare war;
	
	private Joueur A;
	private Joueur B;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu mp = new Menu();
					mp.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 250);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		titre = new JLabel("Bataille naval");
		titre.setHorizontalAlignment(SwingConstants.CENTER);
		titre.setFont(new Font("Georgia", Font.BOLD, 22));
		titre.setBounds(129, 11, 156, 26);
		contentPane.add(titre);
		
		mode = new JLabel("Mode de jeu");
		mode.setHorizontalAlignment(SwingConstants.CENTER);
		mode.setFont(new Font("Georgia", Font.BOLD, 18));
		mode.setBounds(10, 48, 156, 26);
		contentPane.add(mode);
		
		type = new JLabel("Type de partie");
		type.setHorizontalAlignment(SwingConstants.CENTER);
		type.setFont(new Font("Georgia", Font.BOLD, 18));
		type.setBounds(268, 48, 156, 26);
		contentPane.add(type);
		
		rbDemo = new JRadioButton("D\u00E9monstration");
		groupeM.add(rbDemo);
		rbDemo.setFont(new Font("Georgia", Font.PLAIN, 12));
		rbDemo.setBounds(30, 81, 120, 23);
		contentPane.add(rbDemo);
		rbDemo.setSelected(true);
		
		rb1J = new JRadioButton("1 Joueur");
		groupeM.add(rb1J);
		rb1J.setFont(new Font("Georgia", Font.PLAIN, 12));
		rb1J.setBounds(30, 107, 120, 23);
		contentPane.add(rb1J);
		
		rb2J = new JRadioButton("2 Joueurs");
		groupeM.add(rb2J);
		rb2J.setFont(new Font("Georgia", Font.PLAIN, 12));
		rb2J.setBounds(30, 133, 120, 23);
		contentPane.add(rb2J);
		
		normale = new JRadioButton("Normale");
		groupeT.add(normale);
		normale.setFont(new Font("Georgia", Font.PLAIN, 12));
		normale.setBounds(278, 81, 120, 23);
		contentPane.add(normale);
		normale.setSelected(true);
		
		radar = new JRadioButton("Radar");
		groupeT.add(radar);
		radar.setFont(new Font("Georgia", Font.PLAIN, 12));
		radar.setBounds(278, 107, 120, 23);
		contentPane.add(radar);
		
		artillerie = new JRadioButton("Artillerie");
		groupeT.add(artillerie);
		artillerie.setFont(new Font("Georgia", Font.PLAIN, 12));
		artillerie.setBounds(278, 133, 120, 23);
		contentPane.add(artillerie);
		
		rouge = new JRadioButton("Alerte rouge");
		groupeT.add(rouge);
		rouge.setFont(new Font("Georgia", Font.PLAIN, 12));
		rouge.setBounds(278, 159, 120, 23);
		contentPane.add(rouge);
		
		JButton lancer = new JButton("Lancer");
		lancer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(rbDemo.isSelected()){
					A=new Joueur(false);
					B=new Joueur(false);
					if(normale.isSelected()){
						war=new Warfare(A,B,'n');
						war.init();
						war.setVisible(true);
					}
					else{
						if(radar.isSelected()){
							war=new Warfare(A,B,'r');
							war.init();
							war.setVisible(true);
						}
						else{
							if(artillerie.isSelected()){
								war=new Warfare(A,B,'a');
								war.init();
								war.setVisible(true);
							}
							else{
								if(rouge.isSelected()){
									war=new Warfare(A,B,'o');
									war.init();
									war.setVisible(true);
								}
							}
						}
					}
				}
				if(rb1J.isSelected()){
					A=new Joueur(true);
					B=new Joueur(false);
					if(normale.isSelected()){
						war=new Warfare(A,B,'n');
						war.init();
						war.setVisible(true);
					}
					else{
						if(radar.isSelected()){
							war=new Warfare(A,B,'r');
							war.init();
							war.setVisible(true);
						}
						else{
							if(artillerie.isSelected()){
								war=new Warfare(A,B,'a');
								war.init();
								war.setVisible(true);
							}
							else{
								if(rouge.isSelected()){
									war=new Warfare(A,B,'o');
									war.init();
									war.setVisible(true);
								}
							}
						}
					}
				}
				if(rb2J.isSelected()){
					A=new Joueur(true);
					B=new Joueur(true);
					if(normale.isSelected()){
						war=new Warfare(A,B,'n');
						war.init();
						war.setVisible(true);
					}
					else{
						if(radar.isSelected()){
							war=new Warfare(A,B,'r');
							war.init();
							war.setVisible(true);
						}
						else{
							if(artillerie.isSelected()){
								war=new Warfare(A,B,'a');
								war.init();
								war.setVisible(true);
							}
							else{
								if(rouge.isSelected()){
									war=new Warfare(A,B,'r');
									war.init();
									war.setVisible(true);
								}
							}
						}
					}
				}
			}
		});
		lancer.setBounds(162, 178, 89, 23);
		contentPane.add(lancer);
	}
	
	public static Warfare getWar(){
		return war;
	}
}
