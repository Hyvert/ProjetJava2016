package api;

/**
 * Permet de choisir le mode de jeu et de le lancer.
 * @author Vicblivion
 * @version 1
 */
public class Mode {
	
	//M�thodes
	/**
	 * Lance les diff�rents types de missions avec z�ro � deux joueurs.
	 * @throws InterruptedException 
	 */
	public static void lance(char m,Joueur j1, Joueur j2) throws InterruptedException{
		switch(m){
		case 'n' : Type.missionNormale(j1,j2);
		case 'r' : Type.missionRadar(j1,j2);
		case 'a' : Type.missionArtillerie(j1,j2);
		case 'o' : Type.missionAlerte(j1,j2);
		}
	}
}
