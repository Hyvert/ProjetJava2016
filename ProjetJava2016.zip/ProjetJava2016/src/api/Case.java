package api;
/**
 * Permet de g�rer les cases des diff�rentes grilles.
 * @author Vicblivion & Yvan Ugesic
 * @Version 2
 */
public class Case {
	private boolean touche;
	private boolean occupe;
	private int x;
	private int y;
	
	public Case(boolean touche, boolean occupe,int x,int y){
		this.touche=touche;
		this.occupe=occupe;
		this.setX(x);
		this.setY(y);
	}
	
	public Case(int x,int y){
		this.touche=false;
		this.occupe=false;
		this.x=x;
		this.y=y;
	}
	
	public Case(Case c){
		this.touche=c.getTouche();
		this.occupe=c.getOccupe();
		this.x=c.getX();
		this.y=c.getY();
	}
	
	public void setTouche(boolean t){
		touche=t;
	}
	
	public void setOccupe(boolean n){
		occupe=n;
	}
	
	public boolean getTouche(){
		return touche;
	}
	
	public boolean getOccupe(){
		return occupe;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
}
