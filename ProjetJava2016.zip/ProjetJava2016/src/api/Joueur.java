package api;

import java.util.ArrayList;
import java.util.List;

/**
 * Permet de cr�er des joueurs humains ou ordis.
 * @author Vicblivion
 * @version 3
 */
public class Joueur {
	private boolean humain;
	private Case[][] tir;
	private Case[][] navire;
	private ArrayList<Navire> unite=new ArrayList<Navire>();
	private double dis=0;
	private int[] tp={0,0}; 	//servait pour le radar pour l'ia
	private boolean tour=true;
	private int point;
	
	public Joueur(boolean h){
		humain=h;
		tir=new Case[10][10];
		for(int i=0;i<10;i++){
			for(int j=0;j<10;j++){
				tir[i][j]=new Case(false,false,i,j);
			}
		}
		navire=new Case[10][10];
		for(int i=0;i<10;i++){
			for(int j=0;j<10;j++){
				navire[i][j]=new Case(false,false,i,j);
			}
		}
		point=0;
	}
	
	public Joueur(Joueur j){
		humain=j.humain;
		this.navire= new Case[10][10];
		System.arraycopy(j.navire,  0, navire,  0,  navire.length) ;
		this.tir= new Case[10][10];
		System.arraycopy(j.tir,  0, tir,  0,  tir.length) ;
		point=j.point;
	}
	
	public void setTir(Case[][] t){
		tir=t;
	}
	
	public void setNavire(Case[][] n){
		navire=n;
	}
	public Case[][] getTir(){
		return tir;
	}
	
	public Case[][] getNavire(){
		return navire;
	}
	
	public boolean getHumain(){
		return humain;
	}
	
	public int getPoint(){
		return point;
	}
	
	public void addUnite(Navire n){
		unite.add(n);
		navire[n.getPosition().getX()][n.getPosition().getY()].setOccupe(true);
		if(n.getSens()=='h'){
			for(int i=0;i>-n.getTaille();i--){
				navire[i+n.getPosition().getX()][n.getPosition().getY()].setOccupe(true);
			}
		}
		else if(n.getSens()=='g'){
			for(int i=0;i>-n.getTaille();i--){
				navire[n.getPosition().getX()][i+n.getPosition().getY()].setOccupe(true);
			}
		}
		else if(n.getSens()=='d'){
			for(int i=0;i<n.getTaille();i++){
				navire[n.getPosition().getX()][i+n.getPosition().getY()].setOccupe(true);
			}
		}
		else{
			for(int i=0;i<n.getTaille();i++){
				navire[i+n.getPosition().getX()][n.getPosition().getY()].setOccupe(true);
			}
		}
		
		point+=n.getTaille();
	}
	
	public void toucher(){
		point--;
	}
	
	public void setDis(double d){
		dis=d;
	}
	
	public void setTp(int x, int y){
		tp[0]=x;
		tp[1]=y;
	}
	
	public void setTour(boolean tour) {
		this.tour=tour;
	}
	
	public Case getTCase(int x, int y){
		return tir[x][y];
	}
	
	public Case getNCase(int x, int y){
		return navire[x][y];
	}
	
	public double getDis(){
		return dis;
	}
	
	public int getTpx(){
		return tp[0];
	}
	
	public int getTpy(){
		return tp[1];
	}
	
	public ArrayList<Navire> getUnites(){
		return unite;
	}
	
	public boolean getTour() {
		return tour;
	}
	
	/**
	 * G�re les tirs de l'IA (tirs al�atoires) pour les missions normale et artillerie.
	 * @param un Celui qui tire.
	 * @param deux Celui qui re�oie.
	 */
	public void tirIA(Joueur un, Joueur deux){
		int x=(int) (Math.random()*10);
		int y=(int) (Math.random()*10);
		while(un.getTCase(x,y).getTouche()){
			x=(int) (Math.random()*10);
			y=(int) (Math.random()*10);
		}
		if(un.getTCase(x, y).getOccupe()){
			deux.toucher();
		}
		un.getTCase(x,y).setTouche(true);
		deux.getNCase(x, y).setTouche(true);
		
	}
	
	/**
	 * G�re les tirs IA (Al�atoires) lors des missions radar et alerte rouge.
	 * @param un Celui qui tire.
	 * @param deux Celui qui re�oie.
	 */
	public void tirIAR(Joueur un, Joueur deux){
		int x;
		int y;
		if(un.getDis()==0){
			x=(int) (Math.random()*9);
			y=(int) (Math.random()*9);
		}
		else{
			x=un.getTpx()+(int) (Math.random()*un.getDis());
			y=un.getTpy()+(int) (Math.random()*un.getDis());
		}
		if(!un.getTCase(x,y).getTouche()){
			un.getTCase(x,y).setTouche(true);
			deux.getNCase(x, y).setTouche(true);
			setDis(radar(x,y,deux));
			setTp(x,y);
		}
		else{tirIA(un,deux);}
	}
	
	/**
	 * Indique la distance jusqu'� la cible la plus proche.
	 * @param x Abscisse de la frappe.
	 * @param y Ordonn� de la frappe.
	 * @param deux Celui qui re�oie.
	 * @return La distance � la cible la plus proche.
	 */
	public double radar (int x, int y, Joueur deux){
		double d=11;
		for(int i=0;i<10;i++){
			for(int j=0;j<10;j++){
				if(deux.getNCase(j,i).getOccupe()){
					if(distance(j,i,x,y)<d && distance(j,i,x,y)!=0){d=distance(j,i,x,y);}
				}
			}
		}
		return d;
	}
	
	/**
	 * Calcul la distance entre deux points.
	 * @param j xB
	 * @param i yB
	 * @param x xA
	 * @param y yA
	 * @return La distance
	 */
	public double distance(int j, int i, int x, int y){
		int a=j-x;
		int b=i-y;
		return Math.sqrt(a*a+b*b);
	}
	
	public void tourHumain(){};
}
