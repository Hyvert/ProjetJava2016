package api;

/**
 * Permet d'indiquer la position et l'orientation du navire.
 * @author Yvan Ugesic & Vicblivion
 * @version 1
 */
public class Navire extends TypeNavire{
	private Case position;
	private char sens;
	
	public Navire(int x, int y, char sens, int taille){
		super(taille);
		this.position=new Case(false,true,x,y);
		this.sens=sens;
	}
	
	public Navire(Navire n){
		super(n.getTaille());
		this.position=new Case(n.getPosition());
		this.sens=n.getSens();
	}
	
	public Navire(int x, int y, char sens, TypeNavire type){
		super(type.getTaille());
		this.position=new Case(false,true,x,y);
		this.sens=sens;
	}
	
	public Case getPosition(){
		return position;
	}
	
	public char getSens(){
		return sens;
	}
	
	public int getTaille(){
		return super.getTaille();
	}
	
	public void occuperCase(Case cas, char sens, TypeNavire nav){
		cas.setOccupe(true);
	}
}
