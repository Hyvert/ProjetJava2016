package api;

/**
 * Permet de gerer les diff�rents types de navires.
 * @author Yvan Ugresic
 * @version 1
 */
public class TypeNavire {
	private String nom;
	private int taille;
	private int quantite;
	
	public TypeNavire(int taille){
		this.taille=taille;
		switch(taille){
			case 2 :	this.nom="Zodiac";
						this.quantite=1;
				break;
			case 3 : 	this.nom="Cuirass� furtif";
						this.quantite=2;
				break;
			case 4 : 	this.nom="Sous-marin";
						this.quantite=1;
				break;
			case 5 : 	this.nom="Porte-avion";
						this.quantite=1;	
				break;
			default : break;
		}
	}
	
	public int getTaille(){
		return taille;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getQuantite() {
		return quantite;
	}

	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}
}
