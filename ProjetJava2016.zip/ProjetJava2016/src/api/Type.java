package api;

import gfx.Menu;
import gfx.Warfare;

/**
 * D�finits les actions � r�alis�es selon le type de partie choisie.
 * @author Vicblivion , Yvan Ugresic
 * @version 2
 */
public class Type {

	/**
	 * D�roulement d'une mission normale.
	 * @param un Celui qui tire.
	 * @param deux Celui qui re�oie.
	 */
	public static void missionNormale(Joueur un, Joueur deux){
		if(un.getHumain()){
			un.tourHumain();
			Menu.getWar().refresh(un);
		}
		else{
			un.tirIA(un,deux);
			if(deux.getPoint()>0){
				
				Menu.getWar().refresh(un);
				missionNormale(deux,un);
			}
		}
	}
	
	/**
	 * D�roulement d'une mission radar.
	 * @param un Celui qui tire.
	 * @param deux Celui qui re�oie.
	 */
	public static void missionRadar(Joueur un, Joueur deux){
		if(un.getHumain()){un.tourHumain();Menu.getWar().refresh(un);}
		else{
			un.tirIA(un,deux);
			if(deux.getPoint()>0){
				Menu.getWar().refresh(un);
				missionRadar(deux,un);
			}
		}
	}
	
	/**
	 * D�roulement d'une mission artillerie.
	 * @param un Celui qui tire.
	 * @param deux Celui qui re�oie.
	 */
	public static void missionArtillerie(Joueur un, Joueur deux){
		if(un.getHumain()){un.tourHumain();Menu.getWar().refresh(un);}
		else{
			un.tirIA(un,deux);
			if(deux.getPoint()>0){
				Menu.getWar().refresh(un);
				missionArtillerie(deux,un);
			}
		}
	}
	
	/**
	 * D�roulement d'une mission Alerte rouge.
	 * @param un Celui qui tire.
	 * @param deux Celui qui re�oie.
	 */
	public static void missionAlerte(Joueur un, Joueur deux){
		if(un.getHumain()){un.tourHumain();Menu.getWar().refresh(un);}
		else{
			un.tirIA(un,deux);
			if(deux.getPoint()>0){
				Menu.getWar().refresh(un);
				missionAlerte(deux,un);	
			}
		}
	}
}
